var searchData=
[
  ['nocros',['noCros',['../main_8cpp.html#afe4d0071894b91f6e2c164944d1dc867',1,'main.cpp']]]
];
