var searchData=
[
  ['col',['COL',['../main_8cpp.html#ade5776b4151c77e0c375d1091dae8978',1,'main.cpp']]]
];
