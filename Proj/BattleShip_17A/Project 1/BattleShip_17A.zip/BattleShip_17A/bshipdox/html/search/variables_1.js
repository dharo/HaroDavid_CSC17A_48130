var searchData=
[
  ['hitgrid',['HITGRID',['../main_8cpp.html#a3718105ab26b996f26a5e27920ccc8a8',1,'main.cpp']]],
  ['hitmrk',['hitMrk',['../struct_legend.html#a9a061d9f5e944ca97358214e7c4e0d6b',1,'Legend']]]
];
