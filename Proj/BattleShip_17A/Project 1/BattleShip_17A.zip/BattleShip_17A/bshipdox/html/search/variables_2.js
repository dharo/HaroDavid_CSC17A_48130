var searchData=
[
  ['lgnd',['lgnd',['../struct_legend.html#aec74f6bcc74792152b73b2f20a00d6d3',1,'Legend']]]
];
