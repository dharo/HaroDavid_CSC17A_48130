var searchData=
[
  ['legend',['Legend',['../struct_legend.html',1,'']]]
];
